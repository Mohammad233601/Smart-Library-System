import React, { useEffect, useState } from 'react'
import BookForm from './components/BookForm'
import BookList from './components/BookList'
import api from './api'

export default function App() {
  const [books, setBooks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const fetchBooks = async () => {
    try {
      setLoading(true)
      setError('')
      const res = await api.get('/books')
      setBooks(res.data)
    } catch (err) {
      setError('Failed to load books. Please check if the server is running.')
      console.error('Fetch books failed', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchBooks()
  }, [])

  const addBook = (book) => {
    setBooks(prev => [book, ...prev])
  }

  const removeBook = (id) => {
    setBooks(prev => prev.filter(b => b._id !== id))
  }

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>📚 Library Management System</h1>
        <p>Manage your book collection efficiently</p>
      </header>

      <main className="main-content">
        {error && (
          <div className="error-banner">
            {error}
            <button onClick={fetchBooks} className="retry-btn">Retry</button>
          </div>
        )}

        <BookForm onAdd={addBook} />

        {loading ? (
          <div className="loading-state">
            <p>Loading books...</p>
          </div>
        ) : (
          <BookList books={books} onDelete={removeBook} />
        )}
      </main>

      <footer className="app-footer">
        <p>Library Management System © 2026</p>
        <p>All Rights Reserved to Mohammad Shabbir</p>
      </footer>
    </div>
  )
}
