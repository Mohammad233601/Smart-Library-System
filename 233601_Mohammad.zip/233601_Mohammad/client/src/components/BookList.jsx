import React from 'react'
import api from '../api'

export default function BookList({ books, onDelete }) {
  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this book?')) return
    try {
      await api.delete(`/books/${id}`)
      onDelete(id)
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to delete book')
    }
  }

  if (!books.length) {
    return (
      <div className="empty-state">
        <p>No books found. Add your first book using the form above.</p>
      </div>
    )
  }

  return (
    <div className="book-list-container">
      <h2>Book List ({books.length})</h2>
      <div className="book-list">
        {books.map(book => (
          <div key={book._id} className="book-item">
            <div className="book-info">
              <h3 className="book-title">{book.title}</h3>
              <p className="book-author">by {book.author}</p>
              <div className="book-meta">
                <span className="isbn">ISBN: {book.isbn}</span>
                {book.yearPublished && (
                  <span className="year">Published: {book.yearPublished}</span>
                )}
              </div>
            </div>
            <button 
              className="delete-btn" 
              onClick={() => handleDelete(book._id)}
              aria-label="Delete book"
            >
              Delete
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
