import React, { useState } from 'react'
import api from '../api'

export default function BookForm({ onAdd }) {
  const [form, setForm] = useState({ title: '', author: '', isbn: '', yearPublished: '' })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value })
    setError('')
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    
    if (!form.title.trim() || !form.author.trim() || !form.isbn.trim()) {
      setError('Title, Author, and ISBN are required')
      return
    }

    try {
      setSaving(true)
      const bookData = {
        title: form.title.trim(),
        author: form.author.trim(),
        isbn: form.isbn.trim(),
        yearPublished: form.yearPublished ? Number(form.yearPublished) : undefined
      }
      const res = await api.post('/books', bookData)
      onAdd(res.data)
      setForm({ title: '', author: '', isbn: '', yearPublished: '' })
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to add book')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="book-form-container">
      <form className="book-form" onSubmit={handleSubmit}>
        <h2>Add New Book</h2>
        {error && <div className="error-message">{error}</div>}
        
        <div className="form-group">
          <label htmlFor="title">Book Title *</label>
          <input
            id="title"
            name="title"
            type="text"
            value={form.title}
            onChange={handleChange}
            placeholder="Enter book title"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="author">Author *</label>
          <input
            id="author"
            name="author"
            type="text"
            value={form.author}
            onChange={handleChange}
            placeholder="Enter author name"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="isbn">ISBN *</label>
          <input
            id="isbn"
            name="isbn"
            type="text"
            value={form.isbn}
            onChange={handleChange}
            placeholder="Enter ISBN"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="yearPublished">Year Published</label>
          <input
            id="yearPublished"
            name="yearPublished"
            type="number"
            min="1000"
            max={new Date().getFullYear()}
            value={form.yearPublished}
            onChange={handleChange}
            placeholder="Enter year (optional)"
          />
        </div>

        <button type="submit" className="submit-btn" disabled={saving}>
          {saving ? 'Saving...' : 'Add Book'}
        </button>
      </form>
    </div>
  )
}
