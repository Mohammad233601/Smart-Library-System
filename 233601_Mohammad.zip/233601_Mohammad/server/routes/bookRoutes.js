import express from 'express'
import Book from '../models/Book.js'

const router = express.Router()

// GET all books
router.get('/', async (req, res) => {
  try {
    const books = await Book.find().sort({ createdAt: -1 })
    res.json(books)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

// POST create new book
router.post('/', async (req, res) => {
  try {
    const { title, author, isbn, yearPublished } = req.body

    // Validation
    if (!title || !author || !isbn) {
      return res.status(400).json({ message: 'Title, Author, and ISBN are required' })
    }

    // Check if ISBN already exists
    const existingBook = await Book.findOne({ isbn })
    if (existingBook) {
      return res.status(400).json({ message: 'Book with this ISBN already exists' })
    }

    const book = new Book({
      title,
      author,
      isbn,
      yearPublished: yearPublished || undefined
    })

    const savedBook = await book.save()
    res.status(201).json(savedBook)
  } catch (error) {
    if (error.code === 11000) {
      res.status(400).json({ message: 'ISBN already exists' })
    } else {
      res.status(500).json({ message: error.message })
    }
  }
})

// DELETE book by ID
router.delete('/:id', async (req, res) => {
  try {
    const book = await Book.findByIdAndDelete(req.params.id)
    if (!book) {
      return res.status(404).json({ message: 'Book not found' })
    }
    res.json({ message: 'Book deleted successfully', book })
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

export default router

